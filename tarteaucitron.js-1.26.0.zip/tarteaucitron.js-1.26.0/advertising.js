/* min ready */
tarteaucitronNoAdBlocker = true;